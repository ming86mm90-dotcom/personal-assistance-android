# Enable Google / Microsoft / GitHub Login

The app already has full AppAuth + PKCE scaffolding. You only need to register OAuth clients and paste the Client IDs.

Redirect URI (use this exact value for all three providers):
```
com.example.personalassistant://oauth
```

---

## 1. Google

1. Go to [Google Cloud Console](https://console.cloud.google.com/) → create or select a project.
2. **APIs & Services → Credentials → Create Credentials → OAuth client ID**.
3. Application type: **Android** (or **Web application** if you prefer; both work with AppAuth).
   - For Android type: package name = `com.example.personalassistant`, SHA-1 of your debug/release keystore.
   - For Web type: add the redirect URI above under Authorized redirect URIs.
4. Copy the **Client ID**.
5. Enable the APIs you need (Gmail API, Google Calendar API) under **APIs & Services → Library**.

In `core/auth/AuthManager.kt` replace:
```kotlin
clientId = "YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com",
```
with your real Client ID.

---

## 2. Microsoft

1. Go to [Azure Portal](https://portal.azure.com/) → **Microsoft Entra ID → App registrations → New registration**.
2. Name: Personal Assistant.
3. Supported account types: **Accounts in any organizational directory and personal Microsoft accounts**.
4. Redirect URI: select **Public client/native** and enter:
   ```
   com.example.personalassistant://oauth
   ```
5. After creation, copy the **Application (client) ID**.
6. Under **API permissions** add:
   - Microsoft Graph → Delegated → `Mail.Read`, `Calendars.Read`, `offline_access`, `openid`, `profile`, `email`.
7. (Optional) Grant admin consent if required.

In `AuthManager.kt` replace:
```kotlin
clientId = "YOUR_MICROSOFT_CLIENT_ID",
```

---

## 3. GitHub

1. Go to GitHub → **Settings → Developer settings → OAuth Apps → New OAuth App**.
2. Application name: Personal Assistant.
3. Homepage URL: anything (e.g. `https://github.com`).
4. Authorization callback URL:
   ```
   com.example.personalassistant://oauth
   ```
5. Register the application and copy the **Client ID**.

In `AuthManager.kt` replace:
```kotlin
clientId = "YOUR_GITHUB_CLIENT_ID",
```

---

## After updating the Client IDs

1. Rebuild and run the app.
2. On the login screen tap **Continue with Google / Microsoft / GitHub**.
3. Complete the browser consent flow.
4. You should return to the app and see the provider marked as Connected on the Dashboard.
5. Use the test buttons (Gmail, Calendar, Graph, GitHub repos, etc.) to verify.

### Notes
- The app uses **Authorization Code + PKCE** (no client secret is stored in the app — correct for native clients).
- Tokens are stored in Android Keystore-backed EncryptedSharedPreferences.
- Disconnect buttons attempt provider-side revocation where supported (Google, Microsoft) and always clear local tokens.
- If a provider rejects the custom scheme, you can switch to an HTTPS App Link later (requires domain verification).

That’s all that’s required to enable real login.
