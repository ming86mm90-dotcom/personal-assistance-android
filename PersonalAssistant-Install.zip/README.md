# Personal Assistant — Standalone Native Android App

A complete, self-contained Kotlin + Jetpack Compose Android application.
It works fully offline for chat and local features. OAuth connections (Google, Microsoft, GitHub) are optional for cloud service access.

## Features
- Login screen with optional OAuth (skips login if previously connected)
- Dashboard with connection status, connect/disconnect (with token revoke), and service tests
- Offline chat queue powered by Room (messages persist locally)
- Secure token storage (Android Keystore + EncryptedSharedPreferences)
- Adaptive launcher icon
- Minimal permissions, HTTPS-only network config

## How to build & run
1. Open the `android-app` folder in Android Studio (Ladybug or newer).
2. Let Gradle sync (downloads AppAuth, Room, Compose, etc.).
3. Run on an emulator or device (API 26+).
## Enable real Google / Microsoft / GitHub login
See **[OAUTH-SETUP.md](OAUTH-SETUP.md)** for step-by-step registration instructions and where to paste the Client IDs.

The app is fully standalone — no external backend or PWA is required.

## Structure
- `app/` — single-module Compose app (easy to split into feature modules later)
- Secure token storage via `EncryptedSharedPreferences` + Android Keystore
- Bottom navigation: Dashboard / Chat / Settings
- Minimal permissions (Internet, Network State, Notifications)
- Network security config forces HTTPS

## How to use
1. Open this folder in **Android Studio** (Ladybug or newer recommended).
2. Let Gradle sync (it will download the Android Gradle Plugin and dependencies).
3. Create a launcher icon (or temporarily use the default) — place in `app/src/main/res/mipmap-*`.
4. Run on an emulator or device (API 26+).

## AppAuth OAuth scaffolding (multi-provider)
- `data/AuthManager.kt` — Authorization Code + PKCE for **Google, Microsoft, and GitHub**
- Token refresh support via `refreshToken()`
- Sample service calls:
  - Google: userinfo, Gmail messages, Calendar events
  - Microsoft Graph: /me, mail messages
  - GitHub: user profile, repositories
- Dashboard has Connect + Test buttons for all providers and services
- Provider is tracked via the OAuth `state` parameter
- Tokens stored securely in `SecureTokenStore`

**Before testing:**
1. Register OAuth clients for each provider with redirect URI:
   ```
   com.example.personalassistant://oauth
   ```
2. Replace the `YOUR_*_CLIENT_ID` placeholders in `AuthConfigs`.
3. Open in Android Studio, sync, and run.

## Recent additions
- **Token revocation**: Disconnect buttons call provider revoke endpoints (Google official revoke, Microsoft Graph sessions) where possible, then clear local tokens.
- **ViewModel**: `DashboardViewModel` manages connection state and AuthManager lifecycle.
- **Offline chat queue**: Room database (`ChatMessage` entity) stores messages; Chat screen queues user input offline and shows a simple echo. Pending flag ready for future sync.

## Key files
- `MainActivity.kt` — Compose entry point
- `ui/PersonalAssistantApp.kt` — Navigation
- `data/SecureTokenStore.kt` — Keystore-backed token storage
- `AndroidManifest.xml` — Minimal permissions + OAuth redirect scheme

See the original `android-project-structure.md`, `oauth-guidance.md`, and `AndroidManifest-example.xml` for additional policy notes.

## Organized structure
```
app/src/main/java/com/example/personalassistant/
├── MainActivity.kt
├── PersonalAssistantApp.kt          # Application class
├── core/
│   ├── auth/AuthManager.kt          # OAuth + service calls
│   └── data/
│       ├── SecureTokenStore.kt
│       └── local/                   # Room (ChatMessage, Dao, Database)
├── feature/
│   ├── login/LoginScreen.kt
│   ├── dashboard/
│   │   ├── DashboardScreen.kt
│   │   └── DashboardViewModel.kt
│   ├── chat/ChatScreen.kt
│   └── settings/SettingsScreen.kt
└── ui/
    ├── PersonalAssistantApp.kt      # Navigation
    └── theme/Theme.kt
```
