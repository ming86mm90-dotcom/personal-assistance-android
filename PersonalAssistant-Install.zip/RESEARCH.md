# Internet Deep-Dive Research

The chat screen now triggers a deep-dive research call when you are online and ask a substantial question.

## How it works
- Online + question-like message → `ResearchService` calls backend `GET /api/research?q=...`
- Offline or short message → falls back to the local `OfflineAssistant`
- Backend currently returns a structured placeholder.  
  Replace the body of `/api/research` with a real search API + LLM call for live scraping and AI synthesis.

## Enable live search
Add **one** of these to `backend/.env` and restart:

```bash
# Option A – SerpAPI (easiest)
SERPAPI_KEY=your_key_here

# Option B – Google Custom Search
GOOGLE_CSE_KEY=your_key
GOOGLE_CSE_CX=your_cx

# Option C – Bing Web Search
BING_SEARCH_KEY=your_key
```

The `/api/research` endpoint will then return real ranked results with titles, snippets, and links.

## Security notes
- Endpoint is behind JWT auth.
- Query length is limited.
- Use HTTPS in production and restrict CORS.
- Respect robots.txt and rate limits of any source you scrape.
