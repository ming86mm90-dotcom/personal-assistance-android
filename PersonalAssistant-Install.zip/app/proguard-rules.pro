# Add project-specific keep rules here if needed
-keep class com.example.personalassistant.** { *; }

# AppAuth
-keep class net.openid.appauth.** { *; }
-keepattributes *Annotation*

