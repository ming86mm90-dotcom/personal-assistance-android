package com.example.personalassistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.example.personalassistant.core.security.BiometricLock
import com.example.personalassistant.ui.PersonalAssistantApp
import com.example.personalassistant.ui.theme.PersonalAssistantTheme

class MainActivity : ComponentActivity() {
    private var unlocked by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Biometric gate when available
        if (BiometricLock.canAuthenticate(this)) {
            BiometricLock.authenticate(
                activity = this,
                onSuccess = { unlocked = true },
                onError = { unlocked = true } // allow entry on error/cancel for this starter
            )
        } else {
            unlocked = true
        }

        setContent {
            PersonalAssistantTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    if (unlocked) {
                        PersonalAssistantApp()
                    } else {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    }
                }
            }
        }
    }
}
