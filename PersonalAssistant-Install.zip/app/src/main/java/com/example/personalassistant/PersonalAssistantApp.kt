package com.example.personalassistant

import android.app.Application
import com.example.personalassistant.core.data.local.AppDatabase

class PersonalAssistantApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Pre-initialize Room so the database is ready
        AppDatabase.getInstance(this)
    }
}
