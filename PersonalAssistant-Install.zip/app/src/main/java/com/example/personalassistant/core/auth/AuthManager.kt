package com.example.personalassistant.core.auth

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.result.ActivityResultLauncher
import net.openid.appauth.AuthorizationException
import net.openid.appauth.AuthorizationRequest
import net.openid.appauth.AuthorizationResponse
import net.openid.appauth.AuthorizationService
import net.openid.appauth.AuthorizationServiceConfiguration
import net.openid.appauth.ResponseTypeValues
import net.openid.appauth.TokenRequest
import net.openid.appauth.TokenResponse
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/**
 * Multi-provider AppAuth scaffolding (Authorization Code + PKCE).
 *
 * Supports Google, Microsoft, and GitHub.
 * Replace placeholder CLIENT_IDs with your real registered client IDs.
 * Redirect URI must match the intent-filter in AndroidManifest.xml.
 */
enum class OAuthProvider(val id: String, val displayName: String) {
    GOOGLE("google", "Google"),
    MICROSOFT("microsoft", "Microsoft"),
    GITHUB("github", "GitHub")
}

data class ProviderConfig(
    val clientId: String,
    val authEndpoint: String,
    val tokenEndpoint: String,
    val scope: String,
    val redirectUri: String = "com.example.personalassistant://oauth"
)

object AuthConfigs {
    val configs = mapOf(
        OAuthProvider.GOOGLE to ProviderConfig(
            clientId = "YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com",
            authEndpoint = "https://accounts.google.com/o/oauth2/v2/auth",
            tokenEndpoint = "https://oauth2.googleapis.com/token",
            scope = "openid email profile https://www.googleapis.com/auth/gmail.readonly https://www.googleapis.com/auth/calendar.readonly"
        ),
        OAuthProvider.MICROSOFT to ProviderConfig(
            clientId = "YOUR_MICROSOFT_CLIENT_ID",
            authEndpoint = "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
            tokenEndpoint = "https://login.microsoftonline.com/common/oauth2/v2.0/token",
            scope = "openid email profile offline_access https://graph.microsoft.com/Mail.Read https://graph.microsoft.com/Calendars.Read"
        ),
        OAuthProvider.GITHUB to ProviderConfig(
            clientId = "YOUR_GITHUB_CLIENT_ID",
            authEndpoint = "https://github.com/login/oauth/authorize",
            tokenEndpoint = "https://github.com/login/oauth/access_token",
            scope = "user repo"
        )
    )
}

class AuthManager(
    private val context: Context,
    private val tokenStore: SecureTokenStore
) {
    private val authService = AuthorizationService(context)
    private val httpClient = OkHttpClient()
    private var lastProvider: OAuthProvider? = null

    fun startAuthorization(provider: OAuthProvider, launcher: ActivityResultLauncher<Intent>) {
        lastProvider = provider
        val config = AuthConfigs.configs[provider] ?: return

        val serviceConfig = AuthorizationServiceConfiguration(
            Uri.parse(config.authEndpoint),
            Uri.parse(config.tokenEndpoint)
        )

        val authRequest = AuthorizationRequest.Builder(
            serviceConfig,
            config.clientId,
            ResponseTypeValues.CODE,
            Uri.parse(config.redirectUri)
        )
            .setScope(config.scope)
            .setCodeVerifier(net.openid.appauth.CodeVerifierUtil.generateRandomCodeVerifier()) // PKCE
            .setState(provider.id) // carry provider id in state
            .build()

        val authIntent = authService.getAuthorizationRequestIntent(authRequest)
        launcher.launch(authIntent)
    }

    fun handleAuthorizationResponse(
        data: Intent?,
        onSuccess: (OAuthProvider, TokenResponse) -> Unit,
        onError: (String) -> Unit
    ) {
        val response = AuthorizationResponse.fromIntent(data ?: return)
        val error = AuthorizationException.fromIntent(data)

        if (error != null) {
            onError(error.errorDescription ?: error.error ?: "Authorization failed")
            return
        }

        if (response == null) {
            onError("No authorization response")
            return
        }

        val providerId = response.state ?: lastProvider?.id ?: "google"
        val provider = OAuthProvider.values().find { it.id == providerId } ?: OAuthProvider.GOOGLE

        authService.performTokenRequest(response.createTokenExchangeRequest()) { tokenResponse, exception ->
            if (exception != null || tokenResponse == null) {
                onError(exception?.errorDescription ?: "Token exchange failed")
                return@performTokenRequest
            }

            tokenStore.saveToken(
                provider = provider.id,
                accessToken = tokenResponse.accessToken ?: "",
                refreshToken = tokenResponse.refreshToken
            )

            onSuccess(provider, tokenResponse)
        }
    }

    /**
     * Refresh an access token using the stored refresh token.
     */
    fun refreshToken(
        provider: OAuthProvider,
        onSuccess: (TokenResponse) -> Unit,
        onError: (String) -> Unit
    ) {
        val refreshToken = tokenStore.getRefreshToken(provider.id)
        if (refreshToken.isNullOrBlank()) {
            onError("No refresh token available for ${provider.displayName}")
            return
        }

        val config = AuthConfigs.configs[provider] ?: return
        val serviceConfig = AuthorizationServiceConfiguration(
            Uri.parse(config.authEndpoint),
            Uri.parse(config.tokenEndpoint)
        )

        val tokenRequest = TokenRequest.Builder(
            serviceConfig,
            config.clientId
        )
            .setGrantType("refresh_token")
            .setRefreshToken(refreshToken)
            .setScope(config.scope)
            .build()

        authService.performTokenRequest(tokenRequest) { tokenResponse, exception ->
            if (exception != null || tokenResponse == null) {
                onError(exception?.errorDescription ?: "Token refresh failed")
                return@performTokenRequest
            }

            tokenStore.saveToken(
                provider = provider.id,
                accessToken = tokenResponse.accessToken ?: "",
                refreshToken = tokenResponse.refreshToken ?: refreshToken
            )

            onSuccess(tokenResponse)
        }
    }

    /**
     * Helper for authenticated GET requests.
     */
    private fun authenticatedGet(
        url: String,
        token: String,
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $token")
            .addHeader("Accept", "application/json")
            .build()

        httpClient.newCall(request).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, e: java.io.IOException) {
                onError(e.message ?: "Network error")
            }

            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                val body = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    onError("HTTP ${response.code}: $body")
                    return
                }
                onSuccess(body)
            }
        })
    }

    /**
     * Fetch recent Gmail messages (requires gmail.readonly scope).
     */
    fun fetchGmailMessages(
        maxResults: Int = 5,
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val token = tokenStore.getAccessToken(OAuthProvider.GOOGLE.id)
        if (token.isNullOrBlank()) {
            onError("Google not connected")
            return
        }

        authenticatedGet(
            url = "https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=$maxResults",
            token = token,
            onSuccess = { body ->
                try {
                    val json = JSONObject(body)
                    val messages = json.optJSONArray("messages")
                    val count = messages?.length() ?: 0
                    onSuccess("Found $count recent Gmail message(s)")
                } catch (e: Exception) {
                    onError("Parse error: ${e.message}")
                }
            },
            onError = onError
        )
    }

    /**
     * Fetch upcoming Google Calendar events.
     */
    fun fetchGoogleCalendarEvents(
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val token = tokenStore.getAccessToken(OAuthProvider.GOOGLE.id)
        if (token.isNullOrBlank()) {
            onError("Google not connected")
            return
        }

        val timeMin = java.time.Instant.now().toString()
        authenticatedGet(
            url = "https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=$timeMin&maxResults=5&singleEvents=true&orderBy=startTime",
            token = token,
            onSuccess = { body ->
                try {
                    val json = JSONObject(body)
                    val items = json.optJSONArray("items")
                    val count = items?.length() ?: 0
                    val summary = if (count > 0) {
                        val first = items.getJSONObject(0)
                        val title = first.optString("summary", "Untitled")
                        "Next: $title ($count upcoming)"
                    } else {
                        "No upcoming events"
                    }
                    onSuccess(summary)
                } catch (e: Exception) {
                    onError("Parse error: ${e.message}")
                }
            },
            onError = onError
        )
    }

    /**
     * Fetch Microsoft Graph /me profile.
     */
    fun fetchMicrosoftUserInfo(
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val token = tokenStore.getAccessToken(OAuthProvider.MICROSOFT.id)
        if (token.isNullOrBlank()) {
            onError("Microsoft not connected")
            return
        }

        authenticatedGet(
            url = "https://graph.microsoft.com/v1.0/me",
            token = token,
            onSuccess = { body ->
                try {
                    val json = JSONObject(body)
                    val name = json.optString("displayName", "Unknown")
                    val email = json.optString("mail", json.optString("userPrincipalName", ""))
                    onSuccess("$name <$email>")
                } catch (e: Exception) {
                    onError("Parse error: ${e.message}")
                }
            },
            onError = onError
        )
    }

    /**
     * Fetch recent Microsoft Graph mail messages.
     */
    fun fetchMicrosoftMail(
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val token = tokenStore.getAccessToken(OAuthProvider.MICROSOFT.id)
        if (token.isNullOrBlank()) {
            onError("Microsoft not connected")
            return
        }

        authenticatedGet(
            url = "https://graph.microsoft.com/v1.0/me/messages?\$top=5&\$select=subject,from,receivedDateTime",
            token = token,
            onSuccess = { body ->
                try {
                    val json = JSONObject(body)
                    val messages = json.optJSONArray("value")
                    val count = messages?.length() ?: 0
                    onSuccess("Found $count recent Microsoft mail message(s)")
                } catch (e: Exception) {
                    onError("Parse error: ${e.message}")
                }
            },
            onError = onError
        )
    }

    /**
     * Fetch GitHub authenticated user profile.
     */
    fun fetchGitHubUser(
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val token = tokenStore.getAccessToken(OAuthProvider.GITHUB.id)
        if (token.isNullOrBlank()) {
            onError("GitHub not connected")
            return
        }

        authenticatedGet(
            url = "https://api.github.com/user",
            token = token,
            onSuccess = { body ->
                try {
                    val json = JSONObject(body)
                    val login = json.optString("login", "unknown")
                    val name = json.optString("name", login)
                    val repos = json.optInt("public_repos", 0)
                    onSuccess("$name (@$login) — $repos public repos")
                } catch (e: Exception) {
                    onError("Parse error: ${e.message}")
                }
            },
            onError = onError
        )
    }

    /**
     * Fetch user's GitHub repositories (first page).
     */
    fun fetchGitHubRepos(
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val token = tokenStore.getAccessToken(OAuthProvider.GITHUB.id)
        if (token.isNullOrBlank()) {
            onError("GitHub not connected")
            return
        }

        authenticatedGet(
            url = "https://api.github.com/user/repos?per_page=5&sort=updated",
            token = token,
            onSuccess = { body ->
                try {
                    val array = org.json.JSONArray(body)
                    val count = array.length()
                    val names = (0 until minOf(count, 3)).joinToString(", ") { i ->
                        array.getJSONObject(i).optString("name", "repo")
                    }
                    onSuccess("Repos ($count shown): $names")
                } catch (e: Exception) {
                    onError("Parse error: ${e.message}")
                }
            },
            onError = onError
        )
    }

    /**
     * Best-effort token revocation on the provider, then clear local storage.
     * Google: official revoke endpoint.
     * Microsoft: Graph revokeSignInSessions (when possible).
     * GitHub: local clear only (full revoke needs client secret).
     */
    fun revokeAndClear(
        provider: OAuthProvider,
        onComplete: (String) -> Unit
    ) {
        val access = tokenStore.getAccessToken(provider.id)
        val refresh = tokenStore.getRefreshToken(provider.id)
        val tokenToRevoke = refresh ?: access

        if (tokenToRevoke.isNullOrBlank()) {
            tokenStore.clearProvider(provider.id)
            onComplete("${provider.displayName} already disconnected (local cleared)")
            return
        }

        when (provider) {
            OAuthProvider.GOOGLE -> {
                val request = Request.Builder()
                    .url("https://oauth2.googleapis.com/revoke?token=$tokenToRevoke")
                    .post(okhttp3.RequestBody.create(null, ByteArray(0)))
                    .build()
                httpClient.newCall(request).enqueue(object : okhttp3.Callback {
                    override fun onFailure(call: okhttp3.Call, e: java.io.IOException) {
                        tokenStore.clearProvider(provider.id)
                        onComplete("Google local cleared (revoke network failed)")
                    }
                    override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                        tokenStore.clearProvider(provider.id)
                        val msg = if (response.isSuccessful) "Google token revoked and cleared" else "Google local cleared (revoke returned ${response.code})"
                        onComplete(msg)
                    }
                })
            }
            OAuthProvider.MICROSOFT -> {
                // Best-effort: call Graph revoke sessions if we have a token
                if (!access.isNullOrBlank()) {
                    val request = Request.Builder()
                        .url("https://graph.microsoft.com/v1.0/me/revokeSignInSessions")
                        .post(okhttp3.RequestBody.create(null, ByteArray(0)))
                        .addHeader("Authorization", "Bearer $access")
                        .build()
                    httpClient.newCall(request).enqueue(object : okhttp3.Callback {
                        override fun onFailure(call: okhttp3.Call, e: java.io.IOException) {
                            tokenStore.clearProvider(provider.id)
                            onComplete("Microsoft local cleared (revoke failed)")
                        }
                        override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                            tokenStore.clearProvider(provider.id)
                            val msg = if (response.isSuccessful) "Microsoft sessions revoked and cleared" else "Microsoft local cleared (revoke ${response.code})"
                            onComplete(msg)
                        }
                    })
                } else {
                    tokenStore.clearProvider(provider.id)
                    onComplete("Microsoft local cleared")
                }
            }
            OAuthProvider.GITHUB -> {
                // GitHub full revoke requires client secret; clear local only
                tokenStore.clearProvider(provider.id)
                onComplete("GitHub local tokens cleared (revoke in GitHub settings if needed)")
            }
        }
    }

    fun dispose() {
        authService.dispose()
    }
}
