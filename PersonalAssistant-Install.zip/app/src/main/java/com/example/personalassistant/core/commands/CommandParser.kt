package com.example.personalassistant.core.commands

/**
 * Simple command parser for the unified input bar.
 * Detects note / reminder / normal question.
 */
sealed class UserCommand {
    data class Note(val text: String) : UserCommand()
    data class Reminder(val text: String) : UserCommand()
    data class Question(val text: String) : UserCommand()
}

object CommandParser {
    fun parse(input: String): UserCommand {
        val text = input.trim()
        val lower = text.lowercase()
        return when {
            lower.startsWith("note:") || lower.startsWith("note ") ||
                    lower.startsWith("take a note") || lower.startsWith("new note") ->
                UserCommand.Note(
                    text.substringAfter(":").substringAfter("note").trim()
                        .ifBlank { text }
                )
            lower.startsWith("remind") || lower.contains("reminder") ||
                    lower.startsWith("set a reminder") || lower.startsWith("remind me") ->
                UserCommand.Reminder(text)
            else -> UserCommand.Question(text)
        }
    }
}
