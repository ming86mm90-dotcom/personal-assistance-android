package com.example.personalassistant.core.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Secure token storage using Android Keystore-backed EncryptedSharedPreferences.
 * Use this for OAuth access/refresh tokens. Never log the contents.
 */
class SecureTokenStore(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "secure_tokens",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveToken(provider: String, accessToken: String, refreshToken: String? = null) {
        prefs.edit()
            .putString("${provider}_access", accessToken)
            .apply {
                if (refreshToken != null) putString("${provider}_refresh", refreshToken)
            }
            .apply()
    }

    fun getAccessToken(provider: String): String? = prefs.getString("${provider}_access", null)

    fun getRefreshToken(provider: String): String? = prefs.getString("${provider}_refresh", null)

    fun clearProvider(provider: String) {
        prefs.edit()
            .remove("${provider}_access")
            .remove("${provider}_refresh")
            .apply()
    }

    fun clearAll() {
        prefs.edit().clear().apply()
    }
}
