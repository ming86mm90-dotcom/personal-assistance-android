package com.example.personalassistant.core.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<ChatMessage>>

    @Insert
    suspend fun insert(message: ChatMessage): Long

    @Query("UPDATE chat_messages SET pending = 0 WHERE id = :id")
    suspend fun markSynced(id: Long)

    @Query("SELECT * FROM chat_messages WHERE pending = 1")
    suspend fun getPending(): List<ChatMessage>

    @Query("DELETE FROM chat_messages")
    suspend fun clearAll()
}
