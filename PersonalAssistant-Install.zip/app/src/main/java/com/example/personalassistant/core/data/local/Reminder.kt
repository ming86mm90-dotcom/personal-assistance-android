package com.example.personalassistant.core.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String = "",
    val triggerAt: Long, // epoch millis
    val completed: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
