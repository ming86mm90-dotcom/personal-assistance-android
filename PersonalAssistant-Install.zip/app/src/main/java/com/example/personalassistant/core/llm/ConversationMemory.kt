package com.example.personalassistant.core.llm

import com.example.personalassistant.core.data.local.ChatMessage

object ConversationMemory {
    /**
     * Builds a short context string from the most recent messages.
     */
    fun buildContext(messages: List<ChatMessage>, maxMessages: Int = 6): String {
        return messages.takeLast(maxMessages).joinToString("\n") { msg ->
            val role = if (msg.role == "user") "User" else "Assistant"
            "$role: ${msg.content}"
        }
    }
}
