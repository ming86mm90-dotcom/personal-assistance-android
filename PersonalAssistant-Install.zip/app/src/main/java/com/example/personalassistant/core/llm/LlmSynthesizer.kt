package com.example.personalassistant.core.llm

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Simple LLM helper for synthesizing search results.
 * Configure via SecureTokenStore key "openai" or env-style placeholder.
 */
object LlmSynthesizer {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun synthesize(query: String, sourcesText: String, apiKey: String?, priorContext: String = ""): String {
        if (apiKey.isNullOrBlank()) {
            return sourcesText + "\n\n(Add an OpenAI key in Settings for AI synthesis.)"
        }
        return try {
            val userContent = buildString {
                if (priorContext.isNotBlank()) {
                    append("Prior conversation:\n")
                    append(priorContext)
                    append("\n\n")
                }
                append("Question: $query\n\nSearch results:\n$sourcesText")
            }
            val messages = JSONArray().apply {
                put(JSONObject().put("role", "system").put("content",
                    "You are a helpful assistant. Synthesize a clear, accurate answer from the search results. Cite sources briefly. Use prior conversation context when relevant."))
                put(JSONObject().put("role", "user").put("content", userContent))
            }
            val body = JSONObject()
                .put("model", "gpt-4o-mini")
                .put("messages", messages)
                .put("max_tokens", 500)
                .toString()
                .toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url("https://api.openai.com/v1/chat/completions")
                .addHeader("Authorization", "Bearer $apiKey")
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val respBody = response.body?.string() ?: return sourcesText
            if (!response.isSuccessful) return sourcesText

            val json = JSONObject(respBody)
            json.getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
        } catch (e: Exception) {
            sourcesText + "\n\n(LLM error: ${e.message})"
        }
    }
}
