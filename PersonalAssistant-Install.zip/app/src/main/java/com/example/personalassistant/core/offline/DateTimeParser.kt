package com.example.personalassistant.core.offline

import java.util.Calendar
import java.util.regex.Pattern

/**
 * Lightweight offline date/time parser.
 * Handles "in X hours", "tomorrow", "tomorrow at 3", etc.
 */
object DateTimeParser {
    fun parseToMillis(text: String, now: Long = System.currentTimeMillis()): Long? {
        val lower = text.lowercase()
        val cal = Calendar.getInstance().apply { timeInMillis = now }

        // in X hours / minutes
        val inHours = Regex("in (\\d+) hours?").find(lower)
        if (inHours != null) {
            return now + inHours.groupValues[1].toLong() * 60 * 60 * 1000
        }
        val inMins = Regex("in (\\d+) minutes?").find(lower)
        if (inMins != null) {
            return now + inMins.groupValues[1].toLong() * 60 * 1000
        }

        // tomorrow
        if (lower.contains("tomorrow")) {
            cal.add(Calendar.DAY_OF_YEAR, 1)
            val atHour = Regex("at (\\d{1,2})").find(lower)
            if (atHour != null) {
                cal.set(Calendar.HOUR_OF_DAY, atHour.groupValues[1].toInt())
                cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0)
            } else {
                cal.set(Calendar.HOUR_OF_DAY, 9)
                cal.set(Calendar.MINUTE, 0)
            }
            return cal.timeInMillis
        }

        // next monday etc. (simple)
        if (lower.contains("next week")) {
            cal.add(Calendar.DAY_OF_YEAR, 7)
            return cal.timeInMillis
        }

        return null
    }
}
