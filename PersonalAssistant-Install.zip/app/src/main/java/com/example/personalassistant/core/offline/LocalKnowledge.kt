package com.example.personalassistant.core.offline

import android.content.Context
import com.example.personalassistant.core.data.local.AppDatabase
import kotlinx.coroutines.flow.first

/**
 * Answers questions from local Room data (notes, reminders, chat).
 */
object LocalKnowledge {
    suspend fun answer(context: Context, query: String): String? {
        val db = AppDatabase.getInstance(context)
        val q = query.lowercase()

        if (q.contains("my notes") || q.contains("notes about") || q.contains("what did i note")) {
            val notes = db.noteDao().getAll().first()
            if (notes.isEmpty()) return "You have no notes yet."
            val match = notes.filter {
                it.title.lowercase().contains(q.substringAfter("about").trim()) ||
                        it.body.lowercase().contains(q.take(15))
            }
            return if (match.isNotEmpty()) {
                "Found ${match.size} note(s):\n" + match.take(3).joinToString("\n") { "• ${it.title}: ${it.body.take(80)}" }
            } else {
                "You have ${notes.size} notes. Latest: ${notes.first().title}"
            }
        }

        if (q.contains("reminder") || q.contains("what's next") || q.contains("upcoming")) {
            val reminders = db.reminderDao().getUpcoming().first()
            if (reminders.isEmpty()) return "No upcoming reminders."
            return "Upcoming:\n" + reminders.take(3).joinToString("\n") { "• ${it.title}" }
        }

        if (q.contains("last chat") || q.contains("what did we talk")) {
            val msgs = db.chatDao().getAllMessages().first()
            val last = msgs.lastOrNull { it.role == "user" }
            return last?.let { "You last said: ${it.content}" } ?: "No chat history yet."
        }

        return null
    }
}
