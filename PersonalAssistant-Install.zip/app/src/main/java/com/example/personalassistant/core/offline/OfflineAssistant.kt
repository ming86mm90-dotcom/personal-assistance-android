package com.example.personalassistant.core.offline

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Expanded offline assistant.
 * Handles more intents locally and gives useful replies without any network.
 */
object OfflineAssistant {
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dateFormat = SimpleDateFormat("EEEE, MMM d", Locale.getDefault())

    fun reply(input: String): String {
        val text = input.trim().lowercase()
        val now = Date()

        return when {
            text.isEmpty() -> "I'm here. Everything is saved on this device."

            text.contains("time") -> "Local time is ${timeFormat.format(now)}."
            text.contains("date") || text.contains("today") -> "Today is ${dateFormat.format(now)}."

            text.startsWith("remind") || text.contains("reminder") ->
                "Reminder saved locally. Open the Reminders tab to manage it."

            text.contains("note") || text.contains("remember") || text.contains("write down") ->
                "Saved to your local notes. You can find it in the Notes tab."

            text.contains("hello") || text.contains("hi ") || text == "hi" || text.contains("hey") ->
                "Hello! Fully offline mode. Chat, notes, reminders, search, and voice all work locally."

            text.contains("help") || text.contains("what can you") ->
                """
                Offline features:
                • Chat with local replies
                • Notes (create, search, delete)
                • Reminders with notifications
                • Search across notes & chat
                • Voice input & transcription
                • Export your data
                """.trimIndent()

            text.contains("search") ->
                "Use the Search tab to find anything in your notes and chat history."

            text.contains("weather") ->
                "Weather needs a network. Your other data is still available offline."

            text.contains("thank") -> "You're welcome. Everything stays on this device."

            text.contains("calculate") || text.contains("what is") && text.any { it.isDigit() } ->
                trySimpleMath(text) ?: "Noted offline: \"$input\""

            text.contains("convert") ->
                "Unit conversion works best online. Your note has been saved locally."

            text.contains("my notes") || text.contains("notes about") || text.contains("what's next") ||
                    text.contains("upcoming") || text.contains("last chat") ->
                "Checking your local data…" // actual answer filled by caller via LocalKnowledge

            else -> "Noted offline: \"$input\"\n\n(Research needs a network. Local notes & reminders are available.)"
        }
    }

    private fun trySimpleMath(text: String): String? {
        return try {
            val cleaned = text.replace(Regex("[^0-9+\\-*/.\\s]"), "").trim()
            val parts = cleaned.split(Regex("\\s+")).filter { it.isNotBlank() }
            if (parts.size >= 3) {
                val a = parts[0].toDoubleOrNull() ?: return null
                val op = parts[1]
                val b = parts[2].toDoubleOrNull() ?: return null
                val result = when (op) {
                    "+" -> a + b
                    "-" -> a - b
                    "*" -> a * b
                    "/" -> if (b != 0.0) a / b else return "Cannot divide by zero"
                    else -> return null
                }
                "Result: $result"
            } else null
        } catch (_: Exception) {
            null
        }
    }
}
