package com.example.personalassistant.core.offline

import android.content.Context
import com.example.personalassistant.core.data.local.AppDatabase
import com.example.personalassistant.core.data.local.ChatMessage
import kotlinx.coroutines.flow.first

/**
 * Simple offline cache for previous research-style answers.
 * Stores assistant replies so they can be recalled without network.
 */
object OfflineCache {
    suspend fun findSimilar(context: Context, query: String): String? {
        val dao = AppDatabase.getInstance(context).chatDao()
        val messages = dao.getAllMessages().first()
        val q = query.lowercase()
        return messages
            .filter { it.role == "assistant" && it.content.lowercase().contains(q.take(20)) }
            .maxByOrNull { it.timestamp }
            ?.content
    }

    suspend fun saveResearchResult(context: Context, query: String, answer: String) {
        val dao = AppDatabase.getInstance(context).chatDao()
        dao.insert(ChatMessage(role = "assistant", content = answer, pending = false))
    }
}
