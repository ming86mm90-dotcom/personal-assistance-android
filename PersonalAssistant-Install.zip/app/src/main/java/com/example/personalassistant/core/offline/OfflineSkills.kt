package com.example.personalassistant.core.offline

/**
 * Expanded offline skills: conversions, percentages, timers.
 */
object OfflineSkills {
    fun tryHandle(input: String): String? {
        val t = input.lowercase()
        return when {
            t.contains("percent of") -> percentOf(t)
            t.contains("c to f") || t.contains("celsius") -> cToF(t)
            t.contains("km to miles") || t.contains("kilometers") -> kmToMiles(t)
            t.contains("timer") || t.contains("set timer") -> "Timer noted locally. Use Reminders for timed alerts."
            else -> null
        }
    }

    private fun percentOf(text: String): String? {
        val nums = Regex("(\\d+(?:\\.\\d+)?)").findAll(text).map { it.value.toDouble() }.toList()
        return if (nums.size >= 2) "${nums[0]}% of ${nums[1]} = ${nums[0] / 100 * nums[1]}" else null
    }

    private fun cToF(text: String): String? {
        val n = Regex("(\\d+(?:\\.\\d+)?)").find(text)?.value?.toDoubleOrNull() ?: return null
        return "$n°C = ${n * 9 / 5 + 32}°F"
    }

    private fun kmToMiles(text: String): String? {
        val n = Regex("(\\d+(?:\\.\\d+)?)").find(text)?.value?.toDoubleOrNull() ?: return null
        return "$n km = ${"%.2f".format(n * 0.621371)} miles"
    }
}
