package com.example.personalassistant.core.research

import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object BackendHealth {
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    fun check(baseUrl: String): Boolean {
        return try {
            val req = Request.Builder().url("$baseUrl/health").build()
            val res = client.newCall(req).execute()
            res.isSuccessful
        } catch (_: Exception) {
            false
        }
    }
}
