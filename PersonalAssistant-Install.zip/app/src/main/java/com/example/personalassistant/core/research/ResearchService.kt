package com.example.personalassistant.core.research

import android.content.Context
import com.example.personalassistant.core.llm.LlmSynthesizer
import com.example.personalassistant.core.security.SecurityUtils
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Frontend research service.
 * 1. Tries backend /api/research (preferred — keys stay on server).
 * 2. Falls back to direct search API calls if frontend keys are stored.
 */
object ResearchService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    // Emulator default; change to your machine's LAN IP on a real device
    private const val BACKEND_BASE = "http://10.0.2.2:3000"

    fun research(context: Context, query: String, authToken: String? = null, priorContext: String = ""): String {
        val clean = SecurityUtils.sanitize(query, 500)
        if (clean.isBlank()) return "Please ask a clearer question."

        // Prefer backend (keys never leave the server)
        val backendResult = tryBackend(clean, authToken)
        if (backendResult != null) return backendResult

        // Fallback: direct API if user stored a key locally
        val store = SecureTokenStore(context)
        val serpKey = store.getAccessToken("serpapi")
        if (!serpKey.isNullOrBlank()) {
            val raw = trySerpApi(clean, serpKey)
            val llmKey = store.getAccessToken("openai")
            return LlmSynthesizer.synthesize(clean, raw, llmKey, priorContext)
        }

        return "Research unavailable. Start the backend or add a SerpAPI key in Settings."
    }

    private fun tryBackend(query: String, token: String?): String? {
        return try {
            val url = "$BACKEND_BASE/api/research?q=${java.net.URLEncoder.encode(query, "UTF-8")}"
            val builder = Request.Builder().url(url).get()
            if (!token.isNullOrBlank()) builder.addHeader("Authorization", "Bearer $token")
            val response = client.newCall(builder.build()).execute()
            if (!response.isSuccessful) return null
            val body = response.body?.string() ?: return null
            JSONObject(body).optString("answer", null)
        } catch (_: Exception) {
            null
        }
    }

    private fun trySerpApi(query: String, apiKey: String): String {
        return try {
            val url = "https://serpapi.com/search.json?q=${java.net.URLEncoder.encode(query, "UTF-8")}&api_key=$apiKey&num=5"
            val response = client.newCall(Request.Builder().url(url).build()).execute()
            val body = response.body?.string() ?: return "Empty response from SerpAPI."
            if (!response.isSuccessful) return "SerpAPI error ${response.code}"

            val json = JSONObject(body)
            val organic = json.optJSONArray("organic_results") ?: return "No results."
            val lines = mutableListOf("Deep-dive (direct SerpAPI) for: \"$query\"", "")
            for (i in 0 until minOf(organic.length(), 5)) {
                val item = organic.getJSONObject(i)
                lines += "${i + 1}. ${item.optString("title")}"
                lines += "   ${item.optString("snippet")}"
                lines += "   ${item.optString("link")}"
                lines += ""
            }
            lines.joinToString("\n")
        } catch (e: Exception) {
            "Direct search failed: ${e.message}"
        }
    }

    /** Store a SerpAPI key locally (encrypted) for direct frontend use. */
    fun saveSerpApiKey(context: Context, key: String) {
        SecureTokenStore(context).saveToken("serpapi", key)
    }
}
