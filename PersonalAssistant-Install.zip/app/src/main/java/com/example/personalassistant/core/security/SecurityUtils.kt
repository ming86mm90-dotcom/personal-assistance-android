package com.example.personalassistant.core.security

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

/**
 * Lightweight network and security helpers.
 */
object SecurityUtils {
    fun isOnline(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    /**
     * Basic input sanitization for local display / storage.
     * Strips control characters and limits length.
     */
    fun sanitize(input: String, maxLen: Int = 2000): String {
        return input
            .replace(Regex("[\\p{Cntrl}&&[^\r\n\t]]"), "")
            .trim()
            .take(maxLen)
    }
}
