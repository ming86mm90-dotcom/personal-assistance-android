package com.example.personalassistant.core.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.personalassistant.core.data.SecureTokenStore
import com.example.personalassistant.core.data.local.AppDatabase
import com.example.personalassistant.core.security.SecurityUtils
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Syncs pending chat messages to the backend when online.
 * Only marks synced on HTTP 2xx.
 */
class SyncWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    override suspend fun doWork(): Result {
        if (!SecurityUtils.isOnline(applicationContext)) {
            return Result.retry()
        }

        val store = SecureTokenStore(applicationContext)
        val backend = store.getAccessToken("backend_url") ?: "http://10.0.2.2:3000"
        val token = store.getAccessToken("backend_jwt") // optional

        val dao = AppDatabase.getInstance(applicationContext).chatDao()
        val pending = dao.getPending()

        var anyFailed = false
        pending.forEach { msg ->
            val ok = postMessage(backend, token, msg.content)
            if (ok) {
                dao.markSynced(msg.id)
            } else {
                anyFailed = true
            }
        }

        return if (anyFailed) Result.retry() else Result.success()
    }

    private fun postMessage(base: String, token: String?, content: String): Boolean {
        return try {
            val json = JSONObject().put("message", content).toString()
            val body = json.toRequestBody("application/json".toMediaType())
            val builder = Request.Builder()
                .url("$base/api/chat")
                .post(body)
            if (!token.isNullOrBlank()) {
                builder.addHeader("Authorization", "Bearer $token")
            }
            val response = client.newCall(builder.build()).execute()
            response.isSuccessful
        } catch (_: Exception) {
            false
        }
    }
}
