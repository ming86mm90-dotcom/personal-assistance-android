package com.example.personalassistant.core.voice

import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import java.util.Locale

/**
 * Offline-first voice input.
 * Prefers the on-device recognizer when available.
 * User may need to download an offline language pack:
 * Settings → System → Languages → Speech → On-device recognition.
 */
object VoiceInput {
    fun createRecognizerIntent(prompt: String = "Speak now", preferOffline: Boolean = true): Intent {
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, prompt)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            // Prefer offline engine when the language pack is installed
            if (preferOffline) {
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
        }
    }

    fun extractBestResult(data: Intent?): String? {
        val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        return results?.firstOrNull()?.trim()?.takeIf { it.isNotEmpty() }
    }

    fun extractAllResults(data: Intent?): List<String> {
        return data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() }
            ?: emptyList()
    }

    fun isAvailable(context: Context): Boolean {
        return createRecognizerIntent().resolveActivity(context.packageManager) != null
    }

    /**
     * Guidance shown when offline recognition may be limited.
     */
    fun offlineHelpText(): String = """
        For best offline recognition:
        1. Open device Settings
        2. System → Languages & input → Speech
        3. On-device recognition → Download your language
        Then voice input works without a network.
    """.trimIndent()
}
