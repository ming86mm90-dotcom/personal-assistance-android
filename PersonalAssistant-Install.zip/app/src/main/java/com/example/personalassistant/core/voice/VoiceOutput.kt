package com.example.personalassistant.core.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * AI voice output using system Text-to-Speech.
 * Works offline once the TTS voice data is installed.
 */
class VoiceOutput(context: Context) {
    private var tts: TextToSpeech? = null
    var isReady: Boolean = false
        private set
    var isSpeaking: Boolean = false
        private set

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            isReady = status == TextToSpeech.SUCCESS
            if (isReady) {
                tts?.language = Locale.getDefault()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { isSpeaking = true }
                    override fun onDone(utteranceId: String?) { isSpeaking = false }
                    override fun onError(utteranceId: String?) { isSpeaking = false }
                })
            }
        }
    }

    fun speak(text: String) {
        if (!isReady || text.isBlank()) return
        val clean = text.replace(Regex("\\s+"), " ").take(500)
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "pa_${System.currentTimeMillis()}")
    }

    fun stop() {
        tts?.stop()
        isSpeaking = false
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
        isReady = false
    }
}
