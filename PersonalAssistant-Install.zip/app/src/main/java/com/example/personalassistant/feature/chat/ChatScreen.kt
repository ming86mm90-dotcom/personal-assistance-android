package com.example.personalassistant.feature.chat

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import android.app.Activity
import android.content.Intent
import com.example.personalassistant.core.offline.OfflineSkills
import com.example.personalassistant.core.offline.DateTimeParser
import com.example.personalassistant.ui.components.ChatBubble
import com.example.personalassistant.ui.components.EmptyState
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.FilledTonalButton
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.personalassistant.core.data.local.AppDatabase
import com.example.personalassistant.core.data.local.ChatMessage
import com.example.personalassistant.core.commands.CommandParser
import com.example.personalassistant.core.commands.UserCommand
import com.example.personalassistant.core.offline.LocalKnowledge
import com.example.personalassistant.core.offline.DateTimeParser
import com.example.personalassistant.core.research.ResearchService
import com.example.personalassistant.core.voice.VoiceInput
import com.example.personalassistant.core.voice.VoiceOutput
import androidx.compose.runtime.DisposableEffect
import com.example.personalassistant.core.security.SecurityUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun ChatScreen() {
    val context = LocalContext.current
    val dao = remember { AppDatabase.getInstance(context).chatDao() }
    val messages by dao.getAllMessages().collectAsState(initial = emptyList())
    var input by remember { mutableStateOf("") }

    var voiceEnabled by remember { mutableStateOf(true) }
    var voiceStatus by remember { mutableStateOf("") }
    val voiceOutput = remember { VoiceOutput(context) }

    DisposableEffect(Unit) {
        onDispose { voiceOutput.shutdown() }
    }

    val voiceLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = VoiceInput.extractBestResult(result.data)
            if (!spoken.isNullOrBlank()) {
                input = spoken
                voiceStatus = "Heard: \"$spoken\""
                // Auto-process if it's a clear note or reminder command
                val cmd = CommandParser.parse(spoken)
                if (cmd is UserCommand.Note || cmd is UserCommand.Reminder) {
                    // Trigger the same send path
                    CoroutineScope(Dispatchers.IO).launch {
                        when (cmd) {
                            is UserCommand.Note -> {
                                dao.insert(ChatMessage(role = "user", content = "Note: ${cmd.text}", pending = false))
                                dao.insert(ChatMessage(role = "assistant", content = "Voice note saved locally.", pending = false))
                                voiceOutput.speak("Note saved")
                            }
                            is UserCommand.Reminder -> {
                                dao.insert(ChatMessage(role = "user", content = cmd.text, pending = false))
                                dao.insert(ChatMessage(role = "assistant", content = "Voice reminder noted. Check Reminders.", pending = false))
                                voiceOutput.speak("Reminder saved")
                            }
                            else -> {}
                        }
                    }
                    input = ""
                    voiceStatus = "Voice command processed"
                }
            } else {
                voiceStatus = "No speech detected"
            }
        } else {
            voiceStatus = "Voice input cancelled"
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Chat (offline-ready)", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Messages are stored locally and answered by the offline assistant.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        LazyColumn(Modifier.weight(1f)) {
            if (messages.isEmpty()) {
                item {
                    EmptyState(
                        title = "No messages yet",
                        subtitle = "Ask a question, take a note, or try voice input."
                    )
                }
            }
            items(messages) { msg ->
                ChatBubble(
                    text = msg.content,
                    isUser = msg.role == "user"
                )
            }
        }

        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            label = { Text("Message") },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        )

        Button(
            onClick = {
                if (input.isNotBlank()) {
                    val text = input.trim()
                    input = ""
                    CoroutineScope(Dispatchers.IO).launch {
                        when (val cmd = CommandParser.parse(text)) {
                            is UserCommand.Note -> {
                                dao.insert(ChatMessage(role = "user", content = "Note: ${cmd.text}", pending = false))
                                dao.insert(ChatMessage(role = "assistant", content = "Saved to notes (local).", pending = false))
                            }
                            is UserCommand.Reminder -> {
                                val trigger = DateTimeParser.parseToMillis(cmd.text)
                                    ?: (System.currentTimeMillis() + 60 * 60 * 1000)
                                val db = AppDatabase.getInstance(context)
                                val id = db.reminderDao().insert(Reminder(title = cmd.text, triggerAt = trigger))
                                ReminderScheduler.schedule(context, id, cmd.text, trigger)
                                dao.insert(ChatMessage(role = "user", content = cmd.text, pending = false))
                                dao.insert(ChatMessage(role = "assistant", content = "Reminder scheduled.", pending = false))
                                if (voiceEnabled) voiceOutput.speak("Reminder scheduled")
                            }
                            is UserCommand.Question -> {
                                dao.insert(ChatMessage(role = "user", content = cmd.text, pending = true))
                                val prior = com.example.personalassistant.core.llm.ConversationMemory.buildContext(messages)
                                val reply = if (SecurityUtils.isOnline(context) && (cmd.text.endsWith("?") || cmd.text.length > 20)) {
                                    ResearchService.research(context, cmd.text, priorContext = prior)
                                } else {
                                    OfflineSkills.tryHandle(cmd.text)
                                        ?: LocalKnowledge.answer(context, cmd.text)
                                        ?: OfflineCache.findSimilar(context, cmd.text)
                                        ?: OfflineAssistant.reply(cmd.text)
                                }
                                dao.insert(ChatMessage(role = "assistant", content = reply, pending = false))
                                if (voiceEnabled) voiceOutput.speak(reply)
                            }
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Send") }

        Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
            FilledTonalButton(
                onClick = {
                    if (VoiceInput.isAvailable(context)) {
                        voiceStatus = "Recording… speak now"
                        voiceLauncher.launch(VoiceInput.createRecognizerIntent("Speak your message", preferOffline = true))
                    } else {
                        voiceStatus = VoiceInput.offlineHelpText()
                    }
                },
                modifier = Modifier.weight(1f)
            ) { Text("🎤 Record") }

            Spacer(Modifier.width(8.dp))

            OutlinedButton(
                onClick = { voiceOutput.stop() },
                modifier = Modifier.weight(1f)
            ) { Text("Stop") }
        }

        OutlinedButton(
            onClick = {
                // AI summarize last few messages
                CoroutineScope(Dispatchers.IO).launch {
                    val recent = messages.takeLast(6).joinToString("\n") { "${it.role}: ${it.content}" }
                    val summary = if (SecurityUtils.isOnline(context)) {
                        ResearchService.research(context, "Summarize this conversation briefly:\n$recent")
                    } else {
                        "Offline summary: ${messages.size} messages in this chat."
                    }
                    dao.insert(ChatMessage(role = "assistant", content = summary, pending = false))
                    if (voiceEnabled) voiceOutput.speak("Here's a summary")
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
        ) { Text("AI: Summarize chat") }

        OutlinedButton(
            onClick = { voiceEnabled = !voiceEnabled },
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
        ) { Text(if (voiceEnabled) "AI voice: ON" else "AI voice: OFF") }

        if (voiceStatus.isNotEmpty()) {
            Text(voiceStatus, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
        }

        Button(
            onClick = { CoroutineScope(Dispatchers.IO).launch { dao.clearAll() } },
            modifier = Modifier.padding(top = 8.dp)
        ) { Text("Clear chat") }
    }
}
