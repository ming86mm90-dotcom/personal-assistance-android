package com.example.personalassistant.feature.dashboard

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.personalassistant.core.auth.OAuthProvider

@Composable
fun DashboardScreen() {
    val context = LocalContext.current
    val viewModel: DashboardViewModel = viewModel(
        factory = object : androidx.lifecycle.ViewModelProvider.Factory {
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return DashboardViewModel(context) as T
            }
        }
    )
    val state by viewModel.state.collectAsState()

    val authLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.authManager.handleAuthorizationResponse(
                data = result.data,
                onSuccess = { p, _ ->
                    viewModel.setStatus("${p.displayName} connected")
                    viewModel.refreshConnectionStatus()
                },
                onError = { e -> viewModel.setStatus(e) }
            )
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Dashboard", style = MaterialTheme.typography.headlineMedium)

        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Connected accounts", style = MaterialTheme.typography.titleMedium)
                Text("Google: ${if (state.google) "Connected" else "Not connected"}")
                Text("Microsoft: ${if (state.microsoft) "Connected" else "Not connected"}")
                Text("GitHub: ${if (state.github) "Connected" else "Not connected"}")

                Button(onClick = { viewModel.authManager.startAuthorization(OAuthProvider.GOOGLE, authLauncher) }) {
                    Text("Connect Google")
                }
                Button(onClick = { viewModel.authManager.startAuthorization(OAuthProvider.MICROSOFT, authLauncher) }) {
                    Text("Connect Microsoft")
                }
                Button(onClick = { viewModel.authManager.startAuthorization(OAuthProvider.GITHUB, authLauncher) }) {
                    Text("Connect GitHub")
                }

                OutlinedButton(onClick = { viewModel.disconnect(OAuthProvider.GOOGLE) }) { Text("Disconnect Google") }
                OutlinedButton(onClick = { viewModel.disconnect(OAuthProvider.MICROSOFT) }) { Text("Disconnect Microsoft") }
                OutlinedButton(onClick = { viewModel.disconnect(OAuthProvider.GITHUB) }) { Text("Disconnect GitHub") }
                OutlinedButton(onClick = { viewModel.disconnectAll() }) { Text("Disconnect all") }
            }
        }

        if (state.statusMessage.isNotEmpty()) {
            Text(state.statusMessage, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
