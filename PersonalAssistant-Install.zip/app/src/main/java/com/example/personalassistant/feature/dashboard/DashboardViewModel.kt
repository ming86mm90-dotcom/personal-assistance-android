package com.example.personalassistant.feature.dashboard

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.personalassistant.core.auth.AuthManager
import com.example.personalassistant.core.auth.OAuthProvider
import com.example.personalassistant.core.data.SecureTokenStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ConnectionState(
    val google: Boolean = false,
    val microsoft: Boolean = false,
    val github: Boolean = false,
    val statusMessage: String = ""
)

class DashboardViewModel(context: Context) : ViewModel() {
    private val tokenStore = SecureTokenStore(context.applicationContext)
    val authManager = AuthManager(context.applicationContext, tokenStore)

    private val _state = MutableStateFlow(ConnectionState())
    val state: StateFlow<ConnectionState> = _state.asStateFlow()

    init {
        refreshConnectionStatus()
    }

    fun refreshConnectionStatus() {
        _state.value = _state.value.copy(
            google = tokenStore.getAccessToken("google") != null,
            microsoft = tokenStore.getAccessToken("microsoft") != null,
            github = tokenStore.getAccessToken("github") != null
        )
    }

    fun setStatus(message: String) {
        _state.value = _state.value.copy(statusMessage = message)
    }

    fun disconnect(provider: OAuthProvider) {
        authManager.revokeAndClear(provider) { msg ->
            viewModelScope.launch {
                setStatus(msg)
                refreshConnectionStatus()
            }
        }
    }

    fun disconnectAll() {
        // Sequential best-effort
        authManager.revokeAndClear(OAuthProvider.GOOGLE) { }
        authManager.revokeAndClear(OAuthProvider.MICROSOFT) { }
        authManager.revokeAndClear(OAuthProvider.GITHUB) { msg ->
            viewModelScope.launch {
                setStatus("All accounts disconnected")
                refreshConnectionStatus()
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        authManager.dispose()
    }
}
