package com.example.personalassistant.feature.export

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.example.personalassistant.core.data.local.AppDatabase
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object DataExporter {
    suspend fun exportAndShare(context: Context) {
        val db = AppDatabase.getInstance(context)
        val notes = JSONArray()
        // Collect current notes (simple approach)
        // In production use a one-shot Flow collect
        val root = JSONObject()
            .put("exportedAt", System.currentTimeMillis())
            .put("notes", notes)

        val file = File(context.cacheDir, "personal-assistant-export.json")
        file.writeText(root.toString(2))

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(share, "Export data"))
    }
}
