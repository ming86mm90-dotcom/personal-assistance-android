package com.example.personalassistant.feature.login

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.personalassistant.core.auth.OAuthProvider
import com.example.personalassistant.feature.dashboard.DashboardViewModel

@Composable
fun LoginScreen(onLoggedIn: () -> Unit) {
    val context = LocalContext.current
    val viewModel: DashboardViewModel = viewModel(
        factory = object : androidx.lifecycle.ViewModelProvider.Factory {
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return DashboardViewModel(context) as T
            }
        }
    )
    val state by viewModel.state.collectAsState()

    val authLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.authManager.handleAuthorizationResponse(
                data = result.data,
                onSuccess = { _, _ -> onLoggedIn() },
                onError = { err -> viewModel.setStatus(err) }
            )
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "Personal Assistant",
            style = MaterialTheme.typography.headlineLarge,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Connect an account or continue offline",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(40.dp))

        Button(
            onClick = { viewModel.authManager.startAuthorization(OAuthProvider.GOOGLE, authLauncher) },
            modifier = Modifier.padding(vertical = 6.dp)
        ) { Text("Continue with Google") }

        Button(
            onClick = { viewModel.authManager.startAuthorization(OAuthProvider.MICROSOFT, authLauncher) },
            modifier = Modifier.padding(vertical = 6.dp)
        ) { Text("Continue with Microsoft") }

        Button(
            onClick = { viewModel.authManager.startAuthorization(OAuthProvider.GITHUB, authLauncher) },
            modifier = Modifier.padding(vertical = 6.dp)
        ) { Text("Continue with GitHub") }

        Spacer(Modifier.height(24.dp))
        OutlinedButton(onClick = onLoggedIn) {
            Text("Continue offline")
        }

        if (state.statusMessage.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            Text(state.statusMessage, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.error)
        }
    }
}
