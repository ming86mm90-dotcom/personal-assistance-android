package com.example.personalassistant.feature.notes

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.personalassistant.core.data.local.AppDatabase
import com.example.personalassistant.core.data.local.Note
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun NotesScreen() {
    val context = LocalContext.current
    val dao = remember { AppDatabase.getInstance(context).noteDao() }
    val notes by dao.getAll().collectAsState(initial = emptyList())
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Notes (offline)", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Title") },
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
        )
        OutlinedTextField(
            value = body,
            onValueChange = { body = it },
            label = { Text("Note") },
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
        )
        Button(
            onClick = {
                if (title.isNotBlank() || body.isNotBlank()) {
                    val t = title.trim()
                    val b = body.trim()
                    title = ""
                    body = ""
                    CoroutineScope(Dispatchers.IO).launch {
                        dao.insert(Note(title = t.ifBlank { "Untitled" }, body = b))
                    }
                }
            },
            modifier = Modifier.padding(vertical = 8.dp)
        ) { Text("Save note") }

        LazyColumn(Modifier.weight(1f)) {
            if (notes.isEmpty()) {
                item {
                    Text(
                        "No notes yet. Add one above.",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
            }
            items(notes) { note ->
                Column(Modifier.padding(vertical = 6.dp)) {
                    Text(note.title, style = MaterialTheme.typography.titleSmall)
                    Text(note.body, style = MaterialTheme.typography.bodyMedium)
                    Button(onClick = {
                        CoroutineScope(Dispatchers.IO).launch { dao.delete(note.id) }
                    }) { Text("Delete") }
                }
            }
        }
    }
}
