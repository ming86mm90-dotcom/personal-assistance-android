package com.example.personalassistant.feature.onboarding

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Welcome", style = MaterialTheme.typography.headlineLarge)
        Text(
            "Your personal assistant works fully offline for notes, reminders, chat, and voice. Connect accounts or a backend only when you want live research.",
            modifier = Modifier.padding(vertical = 16.dp)
        )
        Text("• Offline notes, reminders & search\n• Voice input & spoken replies\n• Optional web research + AI", modifier = Modifier.padding(bottom = 24.dp))
        Button(onClick = onFinish) { Text("Get started") }
    }
}
