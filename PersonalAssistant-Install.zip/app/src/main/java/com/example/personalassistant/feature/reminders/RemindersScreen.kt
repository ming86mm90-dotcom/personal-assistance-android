package com.example.personalassistant.feature.reminders

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.OutlinedButton
import java.util.Calendar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.personalassistant.core.reminders.ReminderScheduler
import com.example.personalassistant.core.data.local.Reminder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RemindersScreen() {
    val context = LocalContext.current
    val dao = remember { AppDatabase.getInstance(context).reminderDao() }
    val reminders by dao.getUpcoming().collectAsState(initial = emptyList())
    var title by remember { mutableStateOf("") }
    val formatter = remember { SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Reminders", style = MaterialTheme.typography.headlineMedium)

        var hoursFromNow by remember { mutableStateOf(1) }

        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Reminder") },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        )
        Text("In $hoursFromNow hour(s)", style = MaterialTheme.typography.bodyMedium)
        OutlinedButton(onClick = { if (hoursFromNow < 48) hoursFromNow++ }) { Text("+1h") }
        OutlinedButton(onClick = { if (hoursFromNow > 1) hoursFromNow-- }) { Text("-1h") }

        Button(onClick = {
            if (title.isNotBlank()) {
                val t = title.trim()
                title = ""
                val trigger = System.currentTimeMillis() + hoursFromNow * 60 * 60 * 1000L
                CoroutineScope(Dispatchers.IO).launch {
                    val id = dao.insert(Reminder(title = t, triggerAt = trigger))
                    ReminderScheduler.schedule(context, id, t, trigger)
                }
            }
        }) { Text("Add reminder") }

        LazyColumn(Modifier.weight(1f).padding(top = 8.dp)) {
            items(reminders) { r ->
                Column(Modifier.padding(vertical = 6.dp)) {
                    Text(r.title, style = MaterialTheme.typography.titleSmall)
                    Text(formatter.format(Date(r.triggerAt)), style = MaterialTheme.typography.bodySmall)
                    Button(onClick = {
                        CoroutineScope(Dispatchers.IO).launch { dao.markCompleted(r.id) }
                    }) { Text("Done") }
                }
            }
        }
    }
}
