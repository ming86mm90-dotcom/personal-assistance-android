package com.example.personalassistant.feature.search

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.personalassistant.core.data.local.AppDatabase

@Composable
fun SearchScreen() {
    val context = LocalContext.current
    val db = remember { AppDatabase.getInstance(context) }
    val notes by db.noteDao().getAll().collectAsState(initial = emptyList())
    val messages by db.chatDao().getAllMessages().collectAsState(initial = emptyList())
    var query by remember { mutableStateOf("") }

    val filteredNotes = notes.filter {
        query.isBlank() || it.title.contains(query, true) || it.body.contains(query, true)
    }
    val filteredMessages = messages.filter {
        query.isBlank() || it.content.contains(query, true)
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Search", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Search notes & chat") },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        )

        LazyColumn(Modifier.weight(1f)) {
            item { Text("Notes", style = MaterialTheme.typography.titleMedium) }
            items(filteredNotes) { n ->
                Text("${n.title}: ${n.body}", Modifier.padding(vertical = 4.dp))
            }
            item { Text("Chat", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp)) }
            items(filteredMessages) { m ->
                Text("${m.role}: ${m.content}", Modifier.padding(vertical = 4.dp))
            }
        }
    }
}
