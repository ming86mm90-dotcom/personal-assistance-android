package com.example.personalassistant.feature.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.personalassistant.core.data.SecureTokenStore
import com.example.personalassistant.core.research.ResearchService
import com.example.personalassistant.feature.export.DataExporter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val store = remember { SecureTokenStore(context.applicationContext) }
    var message by remember { mutableStateOf("") }
    var backendUrl by remember { mutableStateOf(store.getAccessToken("backend_url") ?: "") }
    var serpKey by remember { mutableStateOf("") }
    var openAiKey by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Keys are stored encrypted on this device.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        OutlinedTextField(
            value = backendUrl,
            onValueChange = { backendUrl = it },
            label = { Text("Backend URL") },
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
        )
        Button(onClick = {
            store.saveToken("backend_url", backendUrl.trim())
            message = "Backend URL saved"
        }) { Text("Save URL") }

        OutlinedTextField(
            value = serpKey,
            onValueChange = { serpKey = it },
            label = { Text("SerpAPI key") },
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
        )
        Button(onClick = {
            if (serpKey.isNotBlank()) {
                ResearchService.saveSerpApiKey(context, serpKey.trim())
                serpKey = ""
                message = "SerpAPI key saved"
            }
        }) { Text("Save SerpAPI key") }

        OutlinedTextField(
            value = openAiKey,
            onValueChange = { openAiKey = it },
            label = { Text("OpenAI key") },
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
        )
        Button(onClick = {
            if (openAiKey.isNotBlank()) {
                store.saveToken("openai", openAiKey.trim())
                openAiKey = ""
                message = "OpenAI key saved"
            }
        }) { Text("Save OpenAI key") }

        Button(onClick = {
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    DataExporter.exportAndShare(context)
                } catch (e: Exception) {
                    message = "Export failed: ${e.message}"
                }
            }
        }, modifier = Modifier.padding(top = 8.dp)) { Text("Export data") }

        Button(onClick = {
            store.clearAll()
            message = "All secure data cleared"
        }, modifier = Modifier.padding(top = 4.dp)) { Text("Clear all secure data") }

        if (message.isNotEmpty()) {
            Text(message, Modifier.padding(top = 12.dp))
        }
    }
}
