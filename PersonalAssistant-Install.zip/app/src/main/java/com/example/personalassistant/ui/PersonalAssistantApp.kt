package com.example.personalassistant.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.personalassistant.core.security.SecurityUtils
import com.example.personalassistant.ui.components.OfflineBanner
import com.example.personalassistant.feature.chat.ChatScreen
import com.example.personalassistant.feature.dashboard.DashboardScreen
import com.example.personalassistant.feature.onboarding.OnboardingScreen
import com.example.personalassistant.feature.settings.SettingsScreen

import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import com.example.personalassistant.feature.reminders.RemindersScreen
import com.example.personalassistant.feature.search.SearchScreen

sealed class Screen(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Login : Screen("login", "Login", Icons.Default.Dashboard)
    object Dashboard : Screen("dashboard", "Dashboard", Icons.Default.Dashboard)
    object Chat : Screen("chat", "Chat", Icons.Default.Chat)
    object Notes : Screen("notes", "Notes", Icons.Default.Note)
    object Reminders : Screen("reminders", "Reminders", Icons.Default.Notifications)
    object Search : Screen("search", "Search", Icons.Default.Search)
    object Settings : Screen("settings", "Settings", Icons.Default.Settings)
}

val mainItems = listOf(
    Screen.Dashboard,
    Screen.Chat,
    Screen.Notes,
    Screen.Reminders,
    Screen.Search,
    Screen.Settings
)

@Composable
fun PersonalAssistantApp() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val tokenStore = remember { SecureTokenStore(context.applicationContext) }

    var showOnboarding by remember { mutableStateOf(true) }
    var startDestination by remember { mutableStateOf(Screen.Login.route) }

    // Standalone: skip login if any provider is already connected
    LaunchedEffect(Unit) {
        val hasTokens = tokenStore.getAccessToken("google") != null ||
                tokenStore.getAccessToken("microsoft") != null ||
                tokenStore.getAccessToken("github") != null
        if (hasTokens) {
            isLoggedIn = true
            startDestination = Screen.Dashboard.route
        }
    }

    Scaffold(
        topBar = {
            OfflineBanner(isOffline = !SecurityUtils.isOnline(context))
        },
        bottomBar = {
            if (isLoggedIn) {
                NavigationBar {
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentDestination = navBackStackEntry?.destination
                    mainItems.forEach { screen ->
                        NavigationBarItem(
                            icon = { Icon(screen.icon, contentDescription = screen.title) },
                            label = { Text(screen.title) },
                            selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = if (showOnboarding) "onboarding" else startDestination,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("onboarding") {
                OnboardingScreen(onFinish = {
                    showOnboarding = false
                    navController.navigate(Screen.Login.route) {
                        popUpTo("onboarding") { inclusive = true }
                    }
                })
            }
            composable(Screen.Login.route) {
                LoginScreen(
                    onLoggedIn = {
                        isLoggedIn = true
                        navController.navigate(Screen.Dashboard.route) {
                            popUpTo(Screen.Login.route) { inclusive = true }
                        }
                    }
                )
            }
            composable(Screen.Dashboard.route) { DashboardScreen() }
            composable(Screen.Chat.route) { ChatScreen() }
            composable(Screen.Notes.route) { NotesScreen() }
            composable(Screen.Reminders.route) { RemindersScreen() }
            composable(Screen.Search.route) { SearchScreen() }
            composable(Screen.Settings.route) { SettingsScreen() }
        }
    }
}
