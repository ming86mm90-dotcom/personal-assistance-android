package com.example.personalassistant.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp

data class SourceCardData(
    val title: String,
    val snippet: String,
    val link: String
)

@Composable
fun SourceCard(source: SourceCardData) {
    val uriHandler = LocalUriHandler.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable { runCatching { uriHandler.openUri(source.link) } }
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(source.title, style = MaterialTheme.typography.titleSmall)
            Text(source.snippet, style = MaterialTheme.typography.bodySmall, maxLines = 3)
            Text(source.link, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        }
    }
}
