package com.example.personalassistant.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import com.example.personalassistant.R

/**
 * Simple home-screen widget stub.
 * Shows a static label; extend to launch Chat or Notes.
 */
class AssistantWidget : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        appWidgetIds.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_assistant)
            appWidgetManager.updateAppWidget(id, views)
        }
    }
}
